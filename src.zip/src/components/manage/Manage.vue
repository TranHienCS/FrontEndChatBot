<template>
  <div class="card"> 
      <div class="card-header "> 
      
          <!-- <a class="navbar-brand">Navbar</a> -->
          
          <button type="button" class="btn btn-success add">Add</button>
          <button type="button" class="btn btn-danger ">Remove all</button>

          <!-- <button type="button" class="btn btn-default btn-lg">
            <span class="glyphicon glyphicon-star"></span> Star
          </button> -->
          
          <form class="form-inline right">
            <div>
            <input class="form-control mr-sm-2" type="search" placeholder="Search" v-model="valueSearch" 
                  :onchange="filteredList" aria-label="Search">
           
             <div class="wrapper" v-if="bool">
              <div class="card" v-for="post in filteredList" :key="post.id">
                  <small>{{ post }}</small>
              </div>
            </div>
            </div>
             <button class="btn btn-outline-success my-3 my-sm-0" type="submit" >Search</button>
          </form>
          
        
      </div> 
    
      <div class="card-body manageL row " >
        <div class="nav flex-column nav-pills col-sm-2" id="v-pills-tab" 
            role="tablist" aria-orientation="vertical">
              <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" 
              role="tab" aria-controls="v-pills-home" aria-selected="true" @click="a">Intent</a>
              <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" 
              role="tab" aria-controls="v-pills-profile" aria-selected="false">Entity</a>
        </div>
        
        <div class="tab-content col scroll_bar" id="v-pills-tabContent">
          <div  class="tab-pane fade show active " id="v-pills-home" 
                role="tabpanel" aria-labelledby="v-pills-home-tab" v-if="boolIntent">
            <div class="input-group pb-4 " v-for="(item, index) in listIntent" v-bind:key="item" :value="item" >
                
                <input class="form-check-input btn btn-light ml-4" type="checkbox" value="" id="defaultCheck1">

                <div class="input-group-prepend form-control ml-5 " >
                      {{item}}
                  </div>
                <button type="button" class="btn btn-light butD"  @click="reManageIntent(index)" >
                  <i class="fa fa-window-close"></i>
                </button>
              </div>
            </div>

          <div  class="tab-pane fade" id="v-pills-profile" 
                role="tabpanel" aria-labelledby="v-pills-profile-tab">
              <div class="input-group pb-4 " v-for="(item, index) in listEntitiess" v-bind:key="item" :value="item">
              <input class="form-check-input btn btn-light ml-4" type="checkbox" value="" id="defaultCheck2">
                <div class="input-group-prepend form-control ml-5 " >
                      {{item}}
                  </div>
                <button type="button" class="btn btn-light butD"  @click="reManageEntity(index)" >
                  <i class="fa fa-window-close"></i>
                </button>
              </div>
            </div>
          </div>
        
      </div>
       
  </div>

</template>

<script>
import Search from './Search'

export default {
    props:{
      listIntent: Array,
      listEntitiess: Array,
    },
    data: function(){
      return{
        valueSearch:'',
      // postList:['a', 'b', 'c', 'ab'],
        bool: false,
        boolIntent: true,
      }
    },
    components:{
      appSearch: Search,
    },
   
    computed: {
    filteredList() { 
      this.checkBool();
      return this.listIntent.filter(post => {
        return post.toLowerCase().includes(this.valueSearch.toLowerCase())
        })
       }
     
    },

    methods:{
      reManageIntent(index){
          this.$emit('reManageIntent',index);
      },
      reManageEntity(index){
          this.$emit('reManageEntity',index);
      },
      checkBool(){
        if(this.valueSearch==='')
          this.bool =false;
        else{
          this.bool =true;
        }
      },
       a(){
        console.log(this.listIntent);
      }
    }
  
}
</script>


<style scope>
  .manageL{
    /* position: absolute; */
    
    left: 10%;
    right: 60%;      
  }
  .right{
    float:right;
  }
  .butD{
   width: 8%;
  }
  .add{
    /* right: 50%; */
   width: 9%;
   margin-right:30px;
   margin-left: 280px ;
  }
  .scroll_bar{
    height: 300px;
    overflow-y:scroll;
  }
  .wrapper{
    position: absolute;
    z-index: 9999;
    width: 20.2%;
  }
  
</style>
