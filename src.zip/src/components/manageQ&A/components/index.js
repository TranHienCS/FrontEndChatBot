import VueBootstrapTable from "./VueBootstrapTable";

export default VueBootstrapTable;
