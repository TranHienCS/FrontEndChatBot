<template>
  <div>
    <app-header></app-header>
    <div class="card">
      <div class="card-header">
        <h5>Home</h5>
      </div>
      <div class="card">
        <div class="card-header">
          <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item active" >
              <a class="nav-link active" data-toggle="tab" href="#training">TRAINING</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link " data-toggle="tab" href="#manage">MANAGE </a>
            </li>
          </ul>
        </div>
        <div class="tab-content">
          
        <div id="training" class="card-body tab-pane active">
          <div class="card">
            <div class="card-header">
              TEST HOW YOUR APP UNDERSTANDS ASENTENCE
              <small
                id="helpId"
                class="form-text text-muted"
              >You can train your app by adding more examples</small>
            </div>

            <div class="card-body" >
              <div class="form-group"> 
                  <div class="input-group ">
                    <div class="input-group-prepend mt-1 mr-1">
                      <img src='../../assets/smile.png' width="30" height="30" >
                    </div>
                    <input
                    type="text"
                    v-model="training.question"
                    value=""
                    class="form-control"
                    @keyup.enter="getQuestion()"
                    aria-describedby="helpId"
                    placeholder="User say..."
                    />
                  </div>

                <small id="helpId" class="form-text text-muted">Maximun {{255-training.question.length}} characters long</small>
              </div>

              <div class="input-group w-100" v-if="bool" >
                <app-intent :listIntent="listIntent"  @get_intent="getIntent" :trainingIntent="training.intent"></app-intent>
                <!-- <button type="button" class="btn btn-light" >
                  <i class="fa fa-window-close"></i>
                </button> -->  
              </div>

              <div v-if="checkIntent">
                <app-input :listEntitiess="listEntitiess" @inputEntity="pushEntity"></app-input>
                <div class = "bg-light rounded pt-4">
                  <div v-for="(i,index) in entity" :key="i.id">
                      <app-entity :entity="entity[index]" :ValEntity="valEntity[index]" @reEntity="removeEntity"></app-entity>
                  </div>
                </div>
              </div>
            </div>

            <div class="card-footer text-muted " >
              <form class="form-inline rightBox">
                <box @default_answerWasUpdated="getAnswer" @senderbox="sender" :p_answer="training.answer" :p_default_answer="training.default_answer"></box>
              </form>
            </div>
          </div>
        </div>
        
        <div id="manage" class = "card-body tab-pane " >  
            <app-manage :listIntent="listIntent" :listEntitiess="listEntitiess" @reManageIntent="removeManageIntent" @reManageEntity="removeManageEntity"></app-manage>
        </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import InputEntity from "@/components/training/inputEntity";
import Entity from "@/components/training/Entity";
import Intent from "@/components/training/Intent";
import Box from "@/components/training/Box";
import Header from "@/components/training/Header";
import axios from "axios";
import Sender from "../../helper/sender";
import EntityVue from './Entity.vue';
import Manage from "../manage/Manage"
export default {
  data: function() {
    return {
      training: {
        entities: {},
        params: "",
        intent: "",
        question: "",
        default_answer: "",
        answer: ""
      },
     // entity: ['df', 'dsfdsf', 'dd'],
      entity: [],
     // valEntity: ['df', 'dsfdsf', 'dd'],
      valEntity: [],
      bool: false,
      total: 1,
      listIntent: ['hhh', 'd', 'f', 'ggggg', '     ', 'a','hhdh', 'dd', 'df', 'gggdgg', ' d    ','dlfjdhkjs'],
      listEntitiess: [],
      //listIntent:[]
      
    };
  },
  mounted(){
    axios.get('http://192.168.137.1:4000/business/')
    .then(response=>{
      this.listIntent=response.data.intent;
      this.listEntitiess=response.data.entities;
     // console.log(this.listEntitiess);
     console.log("heloo");
    })
  },
  computed: {
    checkIntent() {
      //console.log(this.training.intent);
      if ((typeof this.training.intent === "undefined")||(this.training.intent === "")) return false;
      else return true;
    },
  },
  methods: { 
    async getQuestion(){
      this.bool = true;
      let question={};
      question.question=this.training.question;
      
      let _intent = await Sender.recieveMessage(question);
      console.log(_intent);
    
      let ab ={};
      ab = _intent.listEn;
      //ab= {a: "b", c:"d"};
      console.log(Object.keys(ab).length);
      for(let i=0;i<Object.keys(ab).length; i++){
      let _params= Object.keys(ab);
      // a[aa[0]];
     // this.training.params= _params[1];
      this.entity.unshift(_params[i]);
      this.valEntity.unshift(ab[_params[i]]);
      }

      this.training.intent=_intent.intent;
      this.training.answer=_intent.answer;
      this.training.default_answer=_intent.default_ans
      
     // this.getIntent(this.training.intent)
     // console.log(this.valEntity);
    }, 

    pushEntity(objEntity){
      this.entity.unshift(objEntity.en);
      this.valEntity.unshift(objEntity.valEn);
      
    },
    sender() {
      this.getEntity();
      Sender.sender(this.training);
     // this.removeData();
    },

    getAnswer(obj_answer) {
      this.training.answer = obj_answer.answer;
      this.training.default_answer = obj_answer.default_answer;
    },
    getEntity() {
      var test = this.entity;
     // console.log(test.length);
      for (let i = 0; i < this.entity.length; i++) {
       // if(test[i])
        this.training.entities[test[i]] = this.valEntity[i];
      }
      this.training.params = test.toString();
    },
    getIntent(obj_intent){
      this.training.intent=obj_intent;
      //console.log(this.training.intent);
      
    },
    removeEntity(En){
      let idx = this.entity.indexOf(En);
      this.entity.splice(idx,1);
      this.valEntity.splice(idx,1);
    },
    removeManageIntent(idx){
      //console.log(idx);
     this.listIntent.splice(idx,1);
    },

    removeManageEntity(idx){
      //let idx = this.entity.indexOf(En);
       console.log(idx);
      
      this.listEntitiess.splice(idx,1);
    },
    // removeData(){
    //   this.training.question='';
    //   this.training.intent='';
    //   this.training.params='';
    //   this.entity.splice(0,this.entity.length);
    //   this.valEntity.splice(0,this.valEntity.length);
    //  // this.listIntent.splice(0, this.listIntent.length)
    // }
  },
  components: {
    box: Box,
    appHeader: Header,
    appEntity:Entity,
    appInput: InputEntity,
    appIntent: Intent,
    appManage: Manage
  }
};
</script>


<style >
.input-group-text {
  width: 100px;
  text-align: center;
}

.rightBox {
  float: right;
}

</style>
