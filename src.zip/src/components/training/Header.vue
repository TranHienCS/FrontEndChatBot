<template>
  <div id="app">
     <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                  <!-- <a class="navbar-brand" href="#">CHAT RESPONSOR</a> -->
                  <!-- Image and text -->
                  <a href="#/chat" > <img src='../../assets/chat.png' width="30" height="30" class="d-inline-block align-top" alt="">
                  </a>
                  <div class="navbar-brand  d-inline-block align-top">CHAT Responsor</div>
                  <!-- <a class="navbar-brand" href="#">
                  <img src='../../assets/chat.png' width="30" height="30" class="d-inline-block align-top" alt="">
                  CHAT Responsor
                  </a> -->
                        
                  

                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mr-auto">
            
                  <li class="nav-item dropdown">
                        <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                        >Page: Nightly </a>
                        <!-- <a>Action</a> -->
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Nightly</a>
                        <a class="dropdown-item" href="#">Nightly2</a>
                        <!-- <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a> -->
                        </div>
                  </li>
                  <li class="nav-item dropdown">
                        <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                        >Category: Nightly </a>
                        <!-- <a>Action</a> -->
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Nightly</a>
                        <a class="dropdown-item" href="#">Nightly2</a>
                        <!-- <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a> -->
                        </div>
                  </li>
                  <li >
                        <div class=" row mt-2 _option" >
                              <div for="sel1" class="col">Language: </div>
                              <select class="language col" id="sel1">
                                    <option>Tiếng Việt</option>
                                    <option>English</option>
                              
                              </select>
                        </div>
                        
                  </li>
                  </ul>

                  <!-- <a class="navbar-brand">Navbar</a> -->
                  <form class="form-inline">
                        <!-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"> -->
                        <button class="btn btn-outline-dark my-2 my-sm-0" type="submit">Login</button>
                  </form>
                  </div>
            </nav>
            </div>
    </div>
  
</template>

<script>

</script>

<style>
._option{
      float: left;
      opacity: 0.6;
      align-items: center;
}
/* .language{
      max-width: 150px;
} */
</style>
