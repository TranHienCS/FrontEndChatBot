import axios from 'axios';
import Swal from 'sweetalert2';
const helper = {
  sender: (objTraining) => {

    axios.post('http://192.168.137.1:4000/business/add', objTraining)
    
      .then((response) => {
        if (response.data.status == 'true') {
          Swal.fire({
            position: 'top-end',
            type: 'success',
            title: 'Your work has been saved',
            showConfirmButton: false,
            timer: 1500
          });
        }
        else {
          Swal.fire({
            position: 'top-end',
            type: 'error',
            title: 'Something went wrong!',
            showConfirmButton: false,
            timer: 1500
          });
        }
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          position: 'top-end',
          type: 'error',
          title: 'Something went wrong!',
          showConfirmButton: false,
          timer: 1500
        });
      })
    console.log(objTraining);
  },

  sendMessage(objmessage){
    return axios.post('http://192.168.137.1:4000/business/send',objmessage)
    .then((res)=>res.data)
    .catch(()=>console.log("error"));
  },
  recieveMessage(question){
    return axios.post('http://192.168.137.1:4000/business/getEntity',question)
    .then(res=>res.data)
    .catch((err)=>console.log(err));
  }
}

export default helper;